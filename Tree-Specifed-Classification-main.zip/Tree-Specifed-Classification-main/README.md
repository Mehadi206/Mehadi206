# Introduction

chat with Arbo Bot for detailed information on species, care, habitats, and forestry topics.

Key capabilities:
- Instant tree/leaf species classification with confidence scores
- Interactive chat assistant specialized in arboriculture
- Modern cyberpunk-inspired UI with smooth animations

## ✨ Features

- **🔬 Neural Tree Classification**: Upload leaf/tree images → Instant species ID via `nateraw/vit-tree-species` ViT model (~92% top-1 accuracy on common species datasets). Confidence scores + animated bars.
- **💬 ArborBot Assistant**: Real-time chat with botanical expert (DeepSeek). Ask about classifications, care tips, habitats. Threaded UI with cyberpunk animations.
- **🎨 Futuristic UI/UX**: Cyberpunk/glassmorphism theme, Motion animations, Tailwind CSS 4, responsive design.
- **⚡ Production-Ready**: Vite HMR, Express proxy server (bypasses CORS), 10MB image support, error handling.
- **🔑 API Proxies**: Secure server-side calls to HF/OpenRouter (no client exposure).

**Usage Examples**:
```
Classification Input: Acer leaf photo
Output: [{label: \"Acer_saccharum\", score: 0.92}, ...]

Chat: \"Tell me about Acer saccharum habitat?\"
ArborBot: \"Sugar Maple (Acer saccharum) thrives in USDA zones 3-8...\"
```

## 🛠 Tech Stack

| Frontend | Backend | AI/ML | Utils |
|----------|---------|-------|-------|
| React 19 | Express/TS | HF ViT (nateraw/vit-tree-species) | Vite 6.2 |
| TypeScript 5.8 | Axios | DeepSeek-Chat (OpenRouter) | Tailwind 4 + Motion |
| Lucide Icons | dotenv + CORS | Vision Transformer | Glassmorphism Effects |

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- [HF Token](https://huggingface.co/settings/tokens) (free tier OK)
- [OpenRouter Key](https://openrouter.ai/keys) (Model)

### 1. Clone & Install
```bash
git clone <repo>
cd Tree-Specifed-Classification
npm install
```

### 2. Setup Env
```bash
# .env.local (server-side only, gitignore'd)
HUGGINGFACE_API_KEY=hf_xxxxxxxx
OPENROUTER_API_KEY=sk-or-...
```

### 3. Dev Server
```bash
npm run dev
```
→ http://localhost:3000

### Scripts
```bash
npm run dev     # Dev server (Vite + Express proxy)
npm run build   # Production build
npm run preview # Preview build
npm run lint    # TS check
npm run clean   # rm -rf dist
```

## 📁 Project Structure
```
.
├── src/
│   ├── App.tsx                 # Root: Header + Hero + Classifier + Chat + Footer
│   ├── components/
│   │   ├── Classifier.tsx      # Image upload + classify results
│   │   ├── Chat.tsx            # ArborBot threaded chat
│   │   ├── Header.tsx, Hero.tsx, Footer.tsx
│   └── lib/api.ts              # classifyTree(), chatWithBot()
├── server.ts                   # Express + Vite dev server + API proxies
├── package.json                # React 19, Tailwind 4, Motion 12, etc.
├── vite.config.ts
└── tsconfig.json
```

## 🔌 API Endpoints (Server-Proxied)

| Endpoint | Method | Body | Response |
|----------|--------|------|----------|
| `/api/classify` | POST | `{ image: base64 }` | `[{label: \"Acer_saccharum\", score: 0.92}]` |
| `/api/chat` | POST | `{ messages: [{role, content}] }` | OpenAI format: `{choices: [{message}]}` |

**classifyTree()** (api.ts example):
```ts
const results = await classifyTree('data:image/jpeg;base64,...');
console.log(results[0]); // {label: 'Species_Name', score: 0.95}
```

## 🤖 Models & Performance

**Classification**: [User Custom HF Space](https://abid1012-tree-specified-classification.hf.space/predict)
- EfficientNetV2M (LeafSnap dataset, 184 classes).
- `/predict` POST: multipart `file` → `{"class": int, "confidence": float, "prediction": probs}`.
- Top-3 results with confidence scores.

**Chat**: [deepseek/deepseek-chat](https://openrouter.ai/models/deepseek/deepseek-chat)
- System Prompt: \"Expert botanist... explain classifications.\"
- Example: Integrates classification results seamlessly.

## 📸 Demos & Screenshots

![Tree Specified Classification - Full App Screenshot](localhost_3000_.png)

**Classification**:
- Upload → Processing → Results with 92% confidence bar.
*(Add screenshot: classifier.png)*

**Chat**:
- Thread: "What is this tree?" → "Sugar Maple, native to... care tips."
*(Add screenshot: chat-demo.png)*

## 🔒 Env & Security
- Keys **server-side only** (server.ts).
- Image limit: 10MB.
- CORS enabled for dev.

## 🧪 Troubleshooting
| Issue | Fix |
|-------|-----|
| \"No API key\" | Set `.env.local`; restart server. |
| Image fail | <10MB JPEG/PNG; check base64. |
| Chat 500 | Verify OpenRouter key/quota. |
| CORS | Use `npm run dev` proxy. |
| Model slow | HF free tier queue; upgrade. |

**Test Endpoints** (curl):
```bash
curl -X POST http://localhost:3000/api/classify -H \"Content-Type: application/json\" -d '{\"image\":\"base64...\"}'
```

**Mock Mode**: Comment proxy calls in server.ts for frontend testing.

## 🌐 Deployment
- **Vercel/Netlify**: Build → static + serverless functions.
- **Render/Heroku**: Full Node (server.ts).
- **Docker**:
```dockerfile
FROM node:22-alpine
COPY . .
RUN npm ci
EXPOSE 3000
CMD [\"npm\", \"run\", \"dev\"]
```

## 🤝 Contributing
1. Fork → `npm i` → branch `feat/your-feature`.
2. Add models/UI/tests → `npm run lint`.
3. PR with demo GIF.
Ideas: Offline TFLite, multi-lang, user gallery.

## 📄 License
MIT © ArborAI Team.

---

🌳 **Classify. Consult. Conserve.** | Questions? Check issues or chat with ArborBot!

