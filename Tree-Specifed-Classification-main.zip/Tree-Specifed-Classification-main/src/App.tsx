import Header from './components/Header';
import Hero from './components/Hero';
import Classifier from './components/Classifier';
import Chat from './components/Chat';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Classifier />
        <Chat />
      </main>
      <Footer />
    </div>
  );
}
