import axios from 'axios';

export interface ClassificationResult {
  label: string;
  score: number;
}

export async function classifyTree(imageBase64: string): Promise<ClassificationResult[]> {
  try {
    const response = await axios.post('/api/classify', { image: imageBase64 });
    return response.data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export async function chatWithBot(messages: ChatMessage[]) {
  try {
    const response = await axios.post('/api/chat', { messages });
    return response.data;
  } catch (error) {
    console.error('Chat Error:', error);
    throw error;
  }
}
