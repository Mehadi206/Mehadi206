import { motion } from 'motion/react';
import { ArrowRight, Terminal } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-[95vh] flex items-center justify-center pt-24 pb-12 px-6 overflow-hidden">
      <div className="absolute inset-0 forest-gradient -z-10" />
      
      {/* Background Decorative elements */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-emerald-500/5 blur-[120px] rounded-full" />
      <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-emerald-700/3 blur-[100px] rounded-full" />

      <div className="max-w-5xl text-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="inline-flex items-center gap-2 glass text-emerald-600 px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] mb-8 border-emerald-500/30"
        >
          <Terminal className="w-3 h-3" />
          Neural Dendrology Interface
        </motion.div>

        <motion.h1 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="font-bold text-6xl md:text-9xl text-gray-900 mb-8 leading-[1] tracking-tighter drop-shadow-sm"
        >
ArborNet AI Taxonomic Classification
        </motion.h1>

        <motion.p 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="text-lg md:text-xl text-gray-700 mb-12 max-w-3xl mx-auto leading-relaxed font-light"
        >
OpenRouter-powered cognitive core
        </motion.p>

        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6"
        >
          <a href="#identify" className="bg-emerald-500 text-black px-10 py-5 rounded-2xl text-sm font-bold uppercase tracking-widest hover:bg-emerald-400 transition-all shadow-[0_0_30px_rgba(16,185,129,0.3)] flex items-center gap-3 group">
            Initialize Scan
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
          <a href="#assistant" className="glass px-10 py-5 rounded-2xl text-sm font-bold uppercase tracking-widest text-emerald-600 hover:bg-gray-100 transition-all border-emerald-500/30">
            Access Cognitive Core
          </a>
        </motion.div>
      </div>
    </section>
  );
}
