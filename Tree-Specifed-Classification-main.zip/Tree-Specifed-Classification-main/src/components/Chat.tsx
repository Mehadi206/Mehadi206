import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, Sparkles } from 'lucide-react';
import { chatWithBot, ChatMessage } from '../lib/api';

export default function Chat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      const response = await chatWithBot(newMessages);
      const assistantMsg = response.choices[0].message;
      setMessages([...newMessages, assistantMsg]);
    } catch (error) {
      setMessages([...newMessages, { role: 'assistant', content: "Hello! 🌳 How can I assist you with trees today? Whether you're curious about a specific species, need care tips, or want help identifying a tree, just let me know! For example:\\n\\n- *\\\"What kind of tree has peeling reddish bark?\\\"* (Could be a **paperbark maple** or **river birch**!)\\n- *\\\"How do I save a dying oak tree?\\\"*\\n- *\\\"Is this tree native to my area?\\\"*\\n\\nAsk away—I'm happy to help!" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="assistant" className="py-24 px-6 bg-gray-50 text-gray-900 min-h-[90vh] flex flex-col items-center overflow-hidden border-t border-gray-200/20">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-px bg-gradient-to-r from-transparent via-emerald-500/50 to-transparent" />
      
      <div className="max-w-5xl w-full flex flex-col h-full flex-1 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 text-emerald-500 font-mono font-bold uppercase tracking-[0.3em] text-[10px] mb-4">
            <Sparkles className="w-4 h-4" />
Cognitive Core // OpenRouter
          </div>
          <h2 className="text-5xl font-bold mb-4 tracking-tighter uppercase text-gray-900">Dendrologist Archive</h2>
          <p className="text-gray-500 max-w-xl mx-auto font-light text-sm">Access the encrypted repository of botanical knowledge. Specialized in silviculture and forest resilience.</p>
        </div>

        <div className="flex-1 glass rounded-[2.5rem] overflow-hidden flex flex-col border-emerald-500/20 mb-8 min-h-[550px] shadow-2xl">
          {/* Header Bar */}
          <div className="px-6 py-4 border-b border-gray-200/10 flex items-center justify-between bg-gray-50/50">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-blue-500 rounded-full glow-green" />
              <span className="text-[10px] font-bold tracking-widest uppercase text-gray-600">Secure Session #0912-B</span>
            </div>
            <div className="text-[10px] font-mono text-emerald-500/60">Status: Encrypted</div>
          </div>

          {/* Chat Window */}
          <div 
            ref={scrollRef}
            className="flex-1 overflow-y-auto p-8 space-y-8 scrollbar-thin scrollbar-thumb-gray-300"
          >
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-emerald-500/40 space-y-4">
                <Bot className="w-20 h-20" />
                <p className="font-mono text-[10px] tracking-widest uppercase">System Standby: Inquire about silva ecosystems</p>
              </div>
            )}
            
            <AnimatePresence>
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <span className={`text-[9px] uppercase tracking-widest font-mono mb-2 ${msg.role === 'user' ? 'text-gray-500 mr-2' : 'text-emerald-500/60 ml-2'}`} >
                    {msg.role === 'user' ? 'Terminal User' : 'Silva Intelligence'}
                  </span>
                  <div className={`max-w-[85%] p-5 rounded-2xl text-sm leading-relaxed
                    ${msg.role === 'user' 
                      ? 'bg-gray-100 rounded-tr-none border border-gray-200 text-gray-800' 
                      : 'bg-emerald-50 rounded-tl-none border border-emerald-200 text-emerald-800 italic'}`} >
                    {msg.content}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {isLoading && (
              <div className="flex flex-col items-start opacity-50">
                <span className="text-[9px] uppercase tracking-widest font-mono mb-2 text-emerald-500/60 ml-2">Processing Query</span>
                <div className="bg-emerald-50/80 p-5 rounded-2xl rounded-tl-none border border-emerald-200">
                  <div className="flex gap-1.5">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse [animation-delay:0.2s]" />
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-6 bg-gray-100 border-t border-gray-200/50">
            <div className="relative group">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Query the botanical archive..."
                className="w-full bg-white border border-gray-300 rounded-2xl px-6 py-4 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:border-emerald-500/50 transition-all pr-14 shadow-sm"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                title="Send message"
                className="absolute right-2 top-2 bottom-2 w-10 bg-emerald-500 text-black rounded-xl hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-20 disabled:grayscale flex items-center justify-center overflow-hidden"
              >
                <div className="relative">
                   <Send className="w-5 h-5" />
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
