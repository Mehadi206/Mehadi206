import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, Camera, X, CheckCircle, Loader2 } from 'lucide-react';
import { classifyTree, ClassificationResult } from '../lib/api';

export default function Classifier() {
  const [image, setImage] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [results, setResults] = useState<ClassificationResult[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResults(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleIdentify = async () => {
    if (!image) return;
    setIsUploading(true);
    setError(null);
    try {
      const res = await classifyTree(image);
      setResults(res);
    } catch (err: any) {
      setError(err.response?.data?.error || "Failed to classify image. Check your Hugging Face API key in server config.");
    } finally {
      setIsUploading(false);
    }
  };

  const reset = () => {
    setImage(null);
    setResults(null);
    setError(null);
  };

  return (
    <section id="identify" className="py-24 px-6 max-w-6xl mx-auto bg-white">
      <div className="text-center mb-16">
        <h2 className="font-bold text-4xl text-gray-900 mb-4 tracking-tight uppercase drop-shadow-sm">Neural Classification</h2>
        <p className="text-emerald-600 font-mono text-sm tracking-widest uppercase">System Ready: Inject Leaf Sample for Analysis</p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-start">
        {/* Upload Column */}
        <div className="space-y-6">
          <div 
            onClick={() => !image && fileInputRef.current?.click()}
            className={`relative aspect-square rounded-[2rem] border-2 transition-all cursor-pointer flex flex-col items-center justify-center p-8 overflow-hidden
              ${image ? 'border-emerald-500/50 glow-green' : 'border-emerald-500/30 glass hover:border-emerald-500/50 bg-gray-50/50 border-dashed'}`}
          >
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
              accept="image/*"
              aria-label="Upload image file"
            />

            <AnimatePresence mode="wait">
              {image ? (
                <motion.div 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }} 
                  exit={{ opacity: 0 }}
                  className="relative w-full h-full"
                >
                  <img src={image} className="w-full h-full object-cover rounded-2xl brightness-75" alt="Preview" />
                  <div className="absolute inset-0 bg-emerald-500/5 pointer-events-none" />
                  <button 
                    onClick={(e) => { e.stopPropagation(); reset(); }}
                    type="button"
                    aria-label="Remove image"
                    className="absolute -top-3 -right-3 bg-red-500 text-white p-2 rounded-full shadow-lg hover:bg-red-600 transition-colors z-10"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </motion.div>
              ) : (
                <motion.div 
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-center"
                >
                  <Upload className="w-12 h-12 text-emerald-500/50 mb-4 mx-auto" />
                  <p className="text-emerald-600 font-mono text-xs tracking-widest uppercase mb-2">[ WAIT: INPUT REQUIRED ]</p>
                  <p className="text-gray-400 text-[10px] uppercase tracking-widest">Target: /dev/input/optical_sensor</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button
            onClick={handleIdentify}
            disabled={!image || isUploading}
            className={`w-full py-5 rounded-2xl font-bold uppercase tracking-widest text-xs transition-all shadow-lg
            type="button"
              ${!image || isUploading 
                ? 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed' 
                : 'bg-emerald-100 border border-emerald-300 text-emerald-700 hover:bg-emerald-200'}`}
          >
            {isUploading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                Executing Neural Map...
              </>
            ) : (
              <>
                <CheckCircle className="w-5 h-5 mr-2" />
                Initiate Run Pulse
              </>
            )}
          </button>
          
          {error && (
            <p className="text-red-500 text-[10px] font-mono uppercase bg-red-50/80 p-4 rounded-xl border border-red-200 tracking-wider">ERROR: {error}</p>
          )}
        </div>

        {/* Results Column */}
        <div className="glass rounded-[2rem] p-8 min-h-[440px] flex flex-col border-emerald-500/30 relative">
          <div className="flex items-center justify-between mb-8 border-b border-gray-200/30 pb-4">
            <h3 className="font-mono text-xs uppercase tracking-widest text-emerald-500/70">Core Analysis Output</h3>
            <span className="text-[10px] font-mono text-gray-500">LOG // 0x4F92</span>
          </div>
          
          <div className="flex-1">
            {results ? (
              <div className="space-y-8">
                {results.map((res, idx) => (
                  <motion.div 
                    key={res.label}
                    initial={{ x: 20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: idx * 0.1 }}
                  >
                    <div className="flex justify-between items-end mb-3">
                      <div>
                        <span className="bg-emerald-500 text-black px-1.5 py-0.5 text-[8px] font-black uppercase rounded mb-1 inline-block">Species Detection</span>
                        <h4 className="font-serif italic text-2xl text-gray-900 tracking-tight leading-none">{res.label.replace(/_/g, ' ')}</h4>
                      </div>
                      <div className="text-right">
                        <div className="accent-text text-2xl font-mono leading-none">{(res.score * 100).toFixed(1)}%</div>
                        <div className="text-[9px] uppercase tracking-widest text-gray-500 font-mono">Confidence</div>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200/50 h-1.5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${res.score * 100}%` }}
                        transition={{ duration: 1, ease: "easeOut" }}
                        className="h-full bg-emerald-500 rounded-full glow-green"
                      />
                    </div>
                  </motion.div>
                ))}
                
                <div className="mt-8 pt-8 border-t border-gray-200">
                  <p className="text-[10px] font-mono text-emerald-500/50 leading-loose uppercase tracking-widest overflow-hidden h-12">
                    {`>> sys.verify_taxonomy(input_map)`}
                    <br />
                    {`>> status: confidence_threshold_achieved`}
                  </p>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-30">
                <Camera className="w-16 h-16 mb-4 text-emerald-500" />
                <p className="text-emerald-600 font-mono text-xs uppercase tracking-[0.2em]">Waiting for Optical Capture</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
