import { TreeDeciduous, Github, Twitter, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer id="about" className="bg-gray-50 py-16 px-6 border-t border-gray-200/20">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between gap-12">
        <div className="max-w-md">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center glow-green">
              <TreeDeciduous className="text-black w-5 h-5" />
            </div>
ArborNet<span className="text-emerald-500">AI</span>
          </div>
          <p className="text-gray-600 text-sm leading-relaxed mb-8 font-light">
            [ SECURE NODE 77-A ] // SYSTEM_STATUS: OPERATIONAL
            <br />
            ArborNet pth v4.2 Engine active. Encrypted cognitive links established via DeepSeek protocol layers.
          </p>
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 rounded-xl glass flex items-center justify-center text-emerald-500 hover:bg-emerald-500/10 transition-all border-emerald-500/20 shadow-sm">
              <Github className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 rounded-xl glass flex items-center justify-center text-emerald-500 hover:bg-emerald-500/10 transition-all border-emerald-500/20 shadow-sm">
              <Twitter className="w-5 h-5" />
            </a>
            <a href="#" className="w-10 h-10 rounded-xl glass flex items-center justify-center text-emerald-500 hover:bg-emerald-500/10 transition-all border-emerald-500/20 shadow-sm">
              <Mail className="w-5 h-5" />
            </a>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-12">
          <div>
            <h4 className="font-bold text-emerald-500/60 mb-6 uppercase tracking-[0.3em] text-[10px]">Neural Map</h4>
            <ul className="space-y-4 text-[10px] text-gray-600 font-mono uppercase tracking-widest">
              <li><a href="#identify" className="hover:text-emerald-500 transition-colors">Taxonomy Scan</a></li>
              <li><a href="#assistant" className="hover:text-emerald-500 transition-colors">Cognitive Archive</a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Model Params</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-emerald-500/60 mb-6 uppercase tracking-[0.3em] text-[10px]">Resources</h4>
            <ul className="space-y-4 text-[10px] text-gray-600 font-mono uppercase tracking-widest">
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Root Database</a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Growth Zones</a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Encrypted Support</a></li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="max-w-6xl mx-auto pt-12 mt-12 border-t border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-4 text-[9px] font-mono text-gray-500 uppercase tracking-[0.3em]">
ArborNet AI
        <div className="flex gap-8">
          <a href="#" className="hover:text-emerald-500 transition-colors">Privacy_Protocol</a>
          <a href="#" className="hover:text-emerald-500 transition-colors">Terms_Execution</a>
        </div>
      </div>
    </footer>
  );
}
