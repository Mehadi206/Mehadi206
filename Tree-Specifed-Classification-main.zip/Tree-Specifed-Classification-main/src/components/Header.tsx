import { TreeDeciduous } from 'lucide-react';
import { motion } from 'motion/react';

export default function Header() {
  return (
    <motion.header 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 left-0 right-0 z-50 glass px-6 py-4 flex items-center justify-between border-b border-gray-200/30"
    >
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center glow-green">
          <TreeDeciduous className="text-black w-6 h-6" />
        </div>
        <div>
ArborNet<span className="text-emerald-500">AI</span>
          <p className="hidden sm:block text-[10px] text-emerald-500/60 uppercase tracking-widest-xl font-mono">ArborNet .pth v4.2 Engine</p>
        </div>
      </div>
      
      <div className="hidden lg:flex items-center gap-4">
        <div className="glass px-4 py-2 rounded-full text-[10px] uppercase font-mono tracking-wider flex items-center gap-2 border-emerald-500/30">
          <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
          <span className="text-emerald-500/90">HF Node: Active</span>
        </div>
        <div className="glass px-4 py-2 rounded-full text-[10px] uppercase font-mono tracking-wider flex items-center gap-2 border-blue-500/30">
          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
OpenRouter: Online
        </div>
      </div>

      <nav className="hidden md:flex items-center gap-8 text-[11px] font-bold uppercase tracking-widest text-emerald-500/80">
        <a href="#identify" className="hover:text-emerald-600 transition-colors">Neural Scans</a>
        <a href="#assistant" className="hover:text-emerald-600 transition-colors">Cognitive Core</a>
      </nav>
    </motion.header>
  );
}
