import express from 'express';
import cors from 'cors';
import axios from 'axios';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

import { config } from 'dotenv';
config({ path: '.env.local' });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json({ limit: '10mb' }));

  // API Routes
  
// Tree Classification Proxy (User HF Space)
  app.post('/api/classify', async (req, res) => {
    try {
      const { image } = req.body; // base64 string
      if (!image) {
        return res.status(400).json({ error: 'No image provided' });
      }

      // Convert base64 to buffer and determine mime type
      const base64Data = image.replace(/^data:image\/[a-zA-Z]+;base64,/, "");
      const buffer = Buffer.from(base64Data, 'base64');
      
      // Create filename from mime type (extract from original data url)
      const mimeMatch = image.match(/^data:image\/([a-zA-Z]+);base64,/);
      const ext = mimeMatch ? mimeMatch[1] : 'jpg';
      const filename = `upload.${ext}`;

      // Use installed form-data package (ES modules compatible)
      const FormDataModule = await import('form-data');
      const FormDataClass = FormDataModule.default;
      const form = new FormDataClass();
      form.append('file', buffer, filename);

      // Call user HF Space API
      const response = await axios.post(
        'https://abid1012-tree-specified-classification.hf.space/predict',
        form,
        {
          headers: form.getHeaders(),
        }
      );

      const data = response.data;
      if (!data.success || !data.prediction) {
        return res.status(500).json({ error: 'Invalid API response' });
      }

      // Convert raw prediction probs to top-3 ClassificationResult format
      // LeafSnap has 184 classes, using indices as placeholder labels
      const prediction = data.prediction[0]; // single image batch
      const topK = 3;
      const results = [];
      
      // Get top 3 predictions
      const indices = prediction.map((prob: number, idx: number) => ({ idx, prob }))
        .sort((a: any, b: any) => b.prob - a.prob)
        .slice(0, topK);

      for (const item of indices) {
        results.push({
          label: `Class_${item.idx}`, // TODO: Map to actual LeafSnap class names
          score: item.prob
        });
      }

      res.json(results);
    } catch (error: any) {
      console.error('Classification error:', error.response?.data || error.message);
      res.status(500).json({ error: 'Failed to classify image', details: error.response?.data || error.message });
    }
  });

  // OpenRouter Proxy (DeepSeek)
  app.post('/api/chat', async (req, res) => {
    try {
      const { messages } = req.body;
      const orKey = process.env.OPENROUTER_API_KEY;
      
      if (!orKey) {
        return res.status(500).json({ error: 'OpenRouter API key not configured on server' });
      }

      const response = await axios.post(
        'https://openrouter.ai/api/v1/chat/completions',
        {
          model: 'deepseek/deepseek-chat',
          messages: [
            {
              role: 'system',
              content: 'You are ArborBot, an expert botanical assistant specializing in tree species, forestry, and arboriculture. Provide accurate, helpful, and scientific information about trees. If a user asks about a specific tree classification result, help them understand its characteristics, habitat, and care.'
            },
            ...messages
          ],
        },
        {
          headers: {
            Authorization: `Bearer ${orKey}`,
            'HTTP-Referer': process.env.APP_URL || 'http://localhost:3000',
            'X-Title': 'ArborAI',
          },
        }
      );

      res.json(response.data);
    } catch (error: any) {
      console.error('Chat error:', error.response?.data || error.message);
      res.status(500).json({ error: 'Failed to connect to chat assistant' });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
